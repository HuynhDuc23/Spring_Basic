package vn.spring.jpa_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
