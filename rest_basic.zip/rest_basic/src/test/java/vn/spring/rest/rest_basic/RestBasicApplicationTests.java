package vn.spring.rest.rest_basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
