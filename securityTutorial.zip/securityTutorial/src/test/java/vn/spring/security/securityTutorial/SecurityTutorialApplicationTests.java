package vn.spring.security.securityTutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
