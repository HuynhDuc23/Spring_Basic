package vn.spring.rest.rest_basic_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestBasicCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
