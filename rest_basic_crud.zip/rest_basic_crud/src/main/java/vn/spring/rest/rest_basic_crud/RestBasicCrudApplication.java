package vn.spring.rest.rest_basic_crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestBasicCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestBasicCrudApplication.class, args);
	}

}
